const todos = [
  {
    id: 1,
    title: 'Buy groceries',
    date: '2023-10-26',
    check: false,
  },
  {
    id: 2,
    title: 'Finish homework',
    date: '2023-10-28',
    check: false,
  },
  {
    id: 3,
    title: 'Go for a run',
    date: '2023-10-27',
    check: true,
  },
];

module.exports = { todos };
